from PyPDF2 import PdfMerger

pdfs = ['dsi_main_text.pdf', 'appendix.pdf']

merger = PdfMerger()

for pdf in pdfs:
    merger.append(pdf)

merger.write("final_paper.pdf")
merger.close()